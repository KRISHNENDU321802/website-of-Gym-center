<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patra Gym</title>
    <link rel="stylesheet" href="style.css">
<style>
   body{
       margin:0px;
       padding:0px;
       background: url('bg.jpg') ;
       /*height:1080px;
       width:1080px;*/
       color:white;
       
    
   } 
   .left{
       position:absolute;
       left:25px;
       top:18px;
      /* border:2px solid red;*/
       display:inline-block;

   }
   .left img{
       width:136px;
   }
   .left div{
       text-align:center;
       color:white;


   }
   .mid{
       left:400px;
        position:absolute;
        display:block;
        width:50%;
        margin:2px solid blue;
        font-family:'baloo bhai',cursive;
        /*border:2px solid blue;*/ 
        
   }
   .right{
       position:absolute;
       right:10px;
       top:20px;
        /*border:2px solid green;*/
        display:inline-block;

   }
   .navbar{
       display:inline-block;
   }
   .navbar li{
       font-size:15px;
       display:inline-block;
   }
   .navbar li a{
       color:white;
       text-decoration: blanchedalmond;
       padding:34px 23px;
   }
   .navbar li a:hover, .navbar li a.active{
       font-size:20px;
       color:blue;
       cursor:pointer;
       
       
   }
  .btn{
      margin:0px 9px;
      color:white;
      background-color:black ;
      padding:4px 4px;
      border-radius:10px;
      cursor:pointer;
  }
  .btn:hover{
      background-color:grey;
      font-size:15px;
  }
  .container{
     /* border:2px solid white;*/
     top:500px;
      margin:2px 2px;
      padding:2px 30px;
      width:40%;
      left:1500px;
      /*border-radius:5px;*/


  }
  .form-group input{

      text-align: center;
      display:block;
      width:300px;
      padding:6px;
      /*border 2px solid black;*/
      margin:15px auto;     
      border-radius:25px;
      background-color:whitesmoke;
      font-family:'Baloo Bhai',cursive;
  }
  .form-group input:hover{
      font-size:20px;
  }


</style>
</head>
<body>
    <!--header class for heading-->
    <header class="header">
        <!--left class for logo-->
        <div class="left">
            <img src="logo.png" alt=""> 
             <div style="background-color:black;"><b><i> Fitness</i></b></div>

        </div>
        <!--mid class for nav bar-->
        <div class="mid">
            <ul class="navbar">
                <li><a href="project.php">Home</a></li>
                <li><a href="aboutus.php">About Us</a></li>
                <li><a href="fit.php">Fitness Calculator</a></li>
                
            </ul>
        </div>
        <!--right class for buttons-->
       <div class="right">
         <button class="btn">Call Us</button>
         <button class="btn">Email Us</button>
       </div>
       


    </header>
    <br><br><br><br><br><br><br><br><br><br><br>
    <br><br>
    <div class="container">
        <center>
            <form>
        <div class="form-group">
                <input type="number" id="a" placeholder="Enter Your HEIGHT in CM">
            </div>
            <div class="form-group">
                <input type="number" id="b" placeholder="Enter Your WEIGHT in KG">
            </div>  
            
            <button onclick="BMI()" id="btn1" class="btn">CHECK HERE...</button> 

            <div><span id="re" style="color:red;"></span></div>
          
            

        </center>
    </div>
    <script>
        function BMI()
{
       var input1 = document.getElementById("a").value;
       var input2 = document.getElementById("b").value;
       input1=input1/100;
       var r1=input2/(input1*input1);
       if(r1>24){
        alert("OVER WEIGHT");   
       }
       else if(r1<18){
           alert("LESS WEIGHT");
       }
       else{
        alert("NORMAL WEIGHT");
       }


}
        </script>

</body>
</html>