<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
    body{
       margin:0px;
       padding:0px;
       background:url('bg.jpg');
       /*height:1080px;
       width:1080px;*/
       color:white;
       opacity=0.5;
    }
    .left{
       position:absolute;
       left:25px;
       top:18px;
      /* border:2px solid red;*/
       display:inline-block;

   }
   .left img{
       width:136px;
   }
   .left div{
       text-align:center;
       color:white;


   }
   .mid{
       left:400px;
        position:absolute;
        display:block;
        width:50%;
        margin:2px solid blue;
        font-family:'baloo bhai',cursive;
        /*border:2px solid blue;*/ 
        
   }
   .right{
       position:absolute;
       right:10px;
       top:20px;
        /*border:2px solid green;*/
        display:inline-block;

   }
   .navbar{
       display:inline-block;
   }
   .navbar li{
       font-size:15px;
       display:inline-block;
   }
   .navbar li a{
       color:white;
       text-decoration: blanchedalmond;
       padding:34px 23px;
   }
   .navbar li a:hover, .navbar li a.active{
       font-size:20px;
       color:blue;
       cursor:pointer;
       
       
   }
  .btn{
      margin:0px 9px;
      color:white;
      background-color:black ;
      padding:4px 4px;
      border-radius:10px;
      cursor:pointer;
  }
  .btn:hover{
      background-color:grey;
      font-size:15px;
  }
  .container{
     /* border:2px solid white;*/
     top:500px;
      margin:2px 2px;
      padding:2px 30px;
      width:40%;
      left:1500px;
      /*border-radius:5px;*/


  }
  .form-group input{

      text-align: center;
      display:block;
      width:300px;
      padding:6px;
      /*border 2px solid black;*/
      margin:15px auto;     
      border-radius:25px;
      background-color:whitesmoke;
      font-family:'Baloo Bhai',cursive;
  }
  .form-group input:hover{
      font-size:20px;
  }
  .ac{
    position:absolute;
       left:300px;
      color:yellow;
    text-align:center;
     
      display:block;
      width:800px;
      padding:6px;
      /*border 2px solid black;*/
      margin:15px auto;     
      border-radius:25px;
      /*background-color:lightgrey;*/
      font-family:'Baloo Bhai',cursive;
  }
    </style>
</head>
<body>
<!--header class for heading-->
<header class="header">
        <!--left class for logo-->
        <div class="left">
            <img src="logo.png" alt=""> 
             <div style="background-color:black;"><b><i>Patra Fitness</i></b></div>

        </div>
        <!--mid class for nav bar-->
        <div class="mid">
            <ul class="navbar">
                <li><a href="project.php">Home</a></li>
                <li><a href="aboutus.php">About Us</a></li>
                <li><a href="fit.php">Fitness Calculator</a></li>
                
            </ul>
        </div>
        <!--right class for buttons-->
       <div class="right">
         <button class="btn">Call Us Now </button>
         <button class="btn">Email Us</button>
       </div>
       


    </header>
    <br>
    <br><br><br><br><br><br>
<div class="ac" align="left">
<b>
<h3>OUR STORY</h3>
<p style="font-size:20px; color:whitesmoke;">
Gym and Fitness was founded in 2002 as a family owned and operated business.<br>
The Gym and Fitness founders didn’t want it to be just another gym equipment<br>
retailer - they wanted to be the best in the industry and set their minds to<br>
doing so! Since its birth, Gym and Fitness has grown into one of Australia’s<br>
largest online fitness equipment retailers having helped over 50,000 customers<br>
 live longer, happier and healthier lives
</p>
</b>
</div>
<br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="ac" align="left">
<b>
<h3>What we do</h3>
<p style="font-size:20px; color:whitesmoke;">
We want to help you live a fit and healthy lifestyle! We do this by helping you<br>
find the most suitable equipment for your home gym, studio or commercial gym,  <br>
keeping your budget, lifestyle and fitness goals in mind. We stock a wide range<br>
of gym equipment, with strength equipment, cardio, cross training and so much <br>
more .Our awesome team is always keen to help, so please call us to discuss your needs.
</p>
</b>
</div
    
</body>
</html>