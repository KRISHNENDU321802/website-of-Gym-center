<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$db="jym";
$a1=strval($_POST['a']);
$a2=$_POST['b'];
$a3=strval($_POST['c']);
$a4=strval($_POST['d']);
$a5=$_POST['e'];



// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql="insert into query (NAME,AGE,GENDER,ADDRESS,MOBILE) values('$a1',$a2,'$a3','$a4','$a5')"; 
if ($conn->query($sql) === TRUE) {
  
  

    
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
?>



  <script>
    alert("DATA STORED SUCCESSFULLY");
    </script>

</body>
</html>
<?php
header("Location:project.php");
?>